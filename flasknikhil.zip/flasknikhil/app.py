from flask import *

app = Flask(__name__)


app.run(debug=True)